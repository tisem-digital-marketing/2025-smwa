#' topic_modelling.R
#' 
#' contributors: 
#'
#' What this file does"
#' - Explores the stm package for topic modelling as applied to hotel reviews
#'

# --- Library --- #
library(readr)
library(dplyr)
library(tibble)
library(tidytext)
library(textstem)
library(stm)      # topic modelling package
library(stringr)
library(ggplot2)

# --- Load Data --- # 
tokens <- 
    read_csv("data/tokens.csv")

# --- Establish a Vocab List --- #
# Keep any word that appears > 5 times
# Note: this is a little ad-hoc

# set up what my vocab list will be
YOURCODE

# Keep only those words in data
YOURCODE

# --- Create Doc-Term-Matrix --- #
YOURCODE

# cast this to a matrix
YOURCODE

# --- Model! --- #
# model
YOURCODE

# --- Explore Output --- #
YOURCODE 

# top 10 words per topic visualized
td_beta <- tidy(hotels_topics)

td_beta %>%
    group_by(topic) %>%
    top_n(10, beta) %>%
    ungroup() %>%
    mutate(topic = paste0("Topic ", topic),
           term = reorder_within(term, beta, topic)) %>%
    ggplot(aes(term, beta, fill = as.factor(topic))) +
    geom_col(alpha = 0.8, show.legend = FALSE) +
    facet_wrap(~ topic, scales = "free_y") +
    coord_flip() +
    scale_x_reordered() +
    labs(x = NULL, y = expression(beta),
         title = "Highest word probabilities for each topic",
         subtitle = "Different words are associated with different topics")

# Which topics are each review about?
reviews_gamma <-
    tidy(hotels_topics,
         matrix = "gamma",
         document_names = rownames(hotels_dtm)
    ) %>%
    rename(id = document)  %>%
    arrange(as.numeric(id))

highest_gamma <- 
    reviews_gamma %>%
    group_by(id) %>%
    slice_max(gamma) %>%
    select(-gamma)

# Merge that into data? 
YOURCODE

# --- Plot some of the Output --- #
# what topics are discussed most?    
df %>%
    count(topic) %>%
    ggplot(aes(reorder(topic, n), n)) + 
    geom_col() + 
    coord_flip()

# Can label topics with human readable names and try again
df <-
    df %>%
    mutate(topic = case_when(
        topic == 1 ~ "LABEL 1",
        topic == 2 ~ "LABEL 2",
        topic == 3 ~ "LABEL 3",
        topic == 4 ~ "LABEL 4",
        topic == 5 ~ "LABEL 5",
        topic == 6 ~ "LABEL 6",
        topic == 7 ~ "LABEL 7",
        topic == 8 ~ "LABEL 8",
        topic == 9 ~ "LABEL 9",
        # final case always uses this odd TRUE ~ notation
        TRUE ~ "LABEL 10"
    )
    )

df %>%
    count(topic) %>%
    ggplot(aes(reorder(topic, n), n)) + 
    geom_col() + 
    coord_flip()

# Are Different topics discussed more often in a deceptive review?
YOURCODE

# --- Extras --- #

# can the computer pick the "right" number of topics?
topics_Kchosen <-
    stm(hotels_dtm,
        # why 10 topics, why not, its an example
        K = 0,
        # seed fixes the random number draw
        # so we should all get the same results
        seed = 123456789)

# Can we choose between our own guesses at the right topic number?
n_tops <- c(5,7,10,13,15)
set.seed(123456789)
topic_search <- searchK(hotels_dtm, K = n_tops, 
                        # N is the number of docs not included in estimation so that
                        # can evaluate model on a "fresh" set of docs
                        # we're using approx 10% of the rows
                        N = floor(0.1*nrow(hotels_dtm)))
plot(topic_search)
