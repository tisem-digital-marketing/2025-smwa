#' intro_text.R
#' 
#' Contributors:
#' 
#' What this file does:
#'  - Introduces students to first founding concepts in text analytics

# --- Libraries --- #
library(readr)     # read files
library(janitor)   # cleanup var names
library(dplyr)     # data manip
library(tibble)    # work with dataframe
library(tidyr)     # data manip
library(ggplot2)   # plotting
library(stringr)   # work with strings
library(tidytext)  # work with text - main functionality
library(textstem)  # stem words
library(tokenizers) # count words
library(reshape2)  # cast from long to wide and vice versa
library(wordcloud) # plot wordclouds

# --- Load Data --- #
df <-
    read_csv('data/reviews.csv') %>%
    clean_names()

# --- Counting Characters and Approx. Word Counts --- #
YOURCODE

# --- Reviews to Tokens --- #
YOURCODE

# --- Stop Words --- # 
YOURCODE

# Plot common words
YOURCODE %>%
    top_n(25) %>%
    ggplot(aes(YOURCODE,
               YOURCODE
    )
    ) +
    geom_col() +
    scale_y_reordered() +
    labs(y = NULL)

#--- Custom Stop Words --- #
YOURCODE

# --- Stemming --- #
YOURCODE 

# Plot words used more or less frequently if deceptive
frequency <- tokens_stem %>%
    count(deceptive, word) %>%
    group_by(deceptive) %>%
    mutate(proportion = n / sum(n)) %>%
    select(-n) %>%
    ungroup()

## As a scatter plot
frequency %>%
    tidyr::pivot_wider(names_from = deceptive, 
                       values_from = proportion, 
                       values_fill = 0
                       ) %>%
    ggplot(
       aes(x = deceptive,
           y = truthful,
           label = word
         )
    ) +
    geom_jitter(alpha = 0.15,
                size = 2.5
                 ) +
    geom_text(aes(label = word),
              check_overlap = TRUE,
              vjust = 1.5
                ) +
    geom_abline(intercept = 0,
                slope = 1,
                lty = 2,
                color = "grey40"
                ) +
    theme_bw() +
    ggtitle("Relative Word Frequencies: Truthful vs Deceptive Reviews") +
    xlab("% of Deceptive Reviews") +
    ylab("% of Truthful Reviews")

## Or as column plots with raw counts
tokens_stem %>%
    group_by(word, deceptive) %>%
    count()  %>%
    ungroup() %>%
    group_by(word) %>%
    mutate(n_total = sum(n)) %>%
    ungroup() %>%
    slice_max(n_total, n = 25) %>%
    ggplot(aes(n, 
               reorder_within(word, n, deceptive)
                )
        ) +
    geom_col() +
    scale_y_reordered() +
    facet_wrap(~deceptive, scales = "free") +
    labs(y = NULL)

# --- Word Clouds --- #
# Separate into good and bad reviews based on rating
# ignore neutral for now
tokens_stem %>%
    count(word, deceptive, sort = TRUE) %>%
    acast(word ~ deceptive, value.var = "n", fill = 0) %>%
    comparison.cloud(colors = c("red", "blue"),
                     max.words = 75)

tokens_stem %>%
    count(word, deceptive, sort = TRUE) %>%
    acast(word ~ deceptive, value.var = "n", fill = 0) %>%
    commonality.cloud(colors = c("black"),
                     max.words = 40)


# save our lemmatized tokens
write_csv(tokens_no_stop, "data/tokens.csv")
