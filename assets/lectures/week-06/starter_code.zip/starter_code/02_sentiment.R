#' 02_sentiment.R
#'
#' Analyse Sentiment in Cardiologist Reviews
#'

# --- Library --- #
library(readr)      # load data
library(dplyr)      # Data Manipulation
library(tibble)     # Work with Dataframes
library(tidyr)      # reshape data
library(stringr)    # work with strings
library(tidytext)   # work with text
library(vader)      # VADER sentiment lexicon
library(tokenizers) # tokenizers
library(textdata)   # "Standard" Sentiment Lexicons
library(textstem)   # word stemmer
library(yardstick)  # assess performance
library(ggplot2)    # plotting

# --- read tokenized data --- #
YOURCODE

# --- Sentiment Analysis - BING --- #
YOURCODE


# We might end up with reviews that do not contain any
# sentiment laden words. They might be dropped from the data
# "Bring them back in" and assign them neutral using this code if needed
# sentiment_bing <- 
#     df %>%
#     rownames_to_column("id") %>%
#     select(id) %>%
#     left_join(YOURCODE, by = "id") %>%
#     mutate(sentiment_bing = replace_na(sentiment_bing, "neutral"))



#--- Compare bing and the star rating?
# First: merge sentiment scores with original data
sentiment_bing <- 
    df %>%
    rownames_to_column("id") %>%
    select(id, doctor_name, sentiment_star) %>%
    inner_join(sentiment_bing, by = "id")

# do our two measures align?
# Confusion Matrix
conf_mat(YOURCODE, 
         YOURCODE, 
         YOURCODE,
         dnn = c("star", "bing"))

accuracy(YOURCODE, 
         as.factor(YOURCODE), 
         as.factor(YOURCODE)
         )

# --- Sentiment Analysis - VADER --- #
# VADER does not want a tidy df .. it wants the raw text string
# Let's do it:

vader_sents <- 
    vader_df(df$review)


# how to get sentiment from this:
# focus on the compound score which is a normalization of the sum of word sentiments 
# so the output lies between -1 and 1
# cutting into pos neg neu using the threshold suggested by original authors
YOURCODE <- 
    YOURCODE %>%
    rowid_to_column("id") %>%
    mutate(vader_class = case_when(
        YOURCODE
        )
    ) %>% 
    select(id, vader_class) %>%
    mutate(id = as.character(id))

# Was VADER Any Better?
# First merge vader results back to original data
df_vader <-
    df %>% 
    inner_join(vader_sents2, by = "id")

# Confusion Matrix
YOUR CODE

# Accuracy
YOUR CODE
