#' intro_text.R
#' 
#' Contributors:
#' 
#' What this file does:
#'  - Introduces students to first founding concepts in text analytics

# --- Libraries --- #
library(readr)     # read files
library(dplyr)     # data manip
library(tibble)    # work with dataframe
library(tidyr)     # data manip
library(ggplot2)   # plotting
library(stringr)   # work with strings
library(tidytext)  # work with text - main functionality
library(textstem)  # stem words
library(tokenizers) # count words
library(reshape2)  # cast from long to wide and vice versa
library(wordcloud) # plot wordclouds

# --- Load Data --- #

# --- Counting Characters and Approx. Word Counts --- #
# INSERT CODE BELOW
# Count Words and characters
YOUR CODE

# BASIC PLOT SETUP - We'll fill this in
# length of reviews by a quick cut of individual rating
df %>%
    ggplot() +
    geom_histogram(
        aes(x = YOUR_CODE)
    ) 

# --- Reviews to Tokens --- #
YOUR CODE

# --- Standard Stop Words --- # 
YOUR CODE 


#--- Custom Stop Words --- #
custom_stop_words <- 
    tibble(
        word = c(
            'doctor',
            'doctors',
            "dr",
            'patient',
            'patients',
            'cardiologist'
        ),
        lexicon = 'docs'
    )

# Plot Common Words after stopword removal
YOUR CODE %>%
    top_n(25) %>%
    ggplot(aes(YOUR CODE, 
               YOUR CODE
        )
    ) +
    geom_col() +
    scale_y_reordered() +
    labs(y = NULL)

# --- Stemming --- #
YOUR CODE

# --- Word Clouds --- #
YOUR CODE %>%
    count(YOURCODE, YOURCODE, sort = TRUE) %>%
    acast(YOURCODE ~ YOURCODE, value.var = "n", fill = 0) %>%
    comparison.cloud(colors = c("red", "blue"),
                     max.words = 50)

