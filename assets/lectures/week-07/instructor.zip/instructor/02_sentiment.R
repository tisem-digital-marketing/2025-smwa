#' 02_sentiment.R
#'
#' Analyse Sentiment in Cardiologist Reviews
#'

# --- Library --- #
library(readr)      # load data
library(dplyr)      # Data Manipulation
library(tibble)     # Work with Dataframes
library(tidyr)      # reshape data
library(stringr)    # work with strings
library(tidytext)   # work with text
library(vader)      # VADER sentiment lexicon
library(tokenizers) # tokenizers
library(textdata)   # "Standard" Sentiment Lexicons
library(textstem)   # word stemmer
library(yardstick)  # assess performance
library(ggplot2)    # plotting

# --- read tokenized data --- #
tokens <- read_csv("data/tokenized_reviews.csv")

df <- read_csv("instructor/data/cardiologist_reviews_ratemd.csv")

# --- Sentiment Analysis - BING --- #
get_sentiments("bing") %>% filter(sentiment == "positive")

tidy_bing <-
    tokens %>%
    left_join(get_sentiments("bing"))

# do this first
tidy_bing_sentiment <-
    tidy_bing %>%
    filter(sentiment != "NA") %>%
    count(sentiment, id) %>%
    mutate(id = as.numeric(id)) %>%
    arrange(id)

sentiment_bing <- 
    tidy_bing_sentiment %>%
    pivot_wider(
        names_from = sentiment,
        values_from = n,
        values_fill = 0
    ) %>%
    mutate(sentiment_bing = case_when(
        positive > negative ~ "positive",
        positive < negative ~ "negative",
        TRUE ~ "neutral"
    )
    ) %>%
    mutate(id = as.character(id))

# We might end up with reviews that do not contain any
# sentiment laden words. They might be dropped from the data
# "Bring them back in" and assign them neutral using this code if needed
sentiment_bing <-
    df %>%
    select(id) %>%
    mutate(id = as.character(id)) %>%
    left_join(sentiment_bing, by = "id") %>%
    mutate(sentiment_bing = replace_na(sentiment_bing, "neutral"))

#--- Compare bing and the star rating?
# First: merge sentiment scores with original data
sentiment_bing <- 
    df %>%
    mutate(id = as.character(id)) %>%
    select(id, doctor_name, sentiment_star) %>%
    inner_join(sentiment_bing, by = "id")

# do our two measures align?
# Confusion Matrix
conf_mat(sentiment_bing, 
         sentiment_star, 
         sentiment_bing,
         dnn = c("star", "bing"))

accuracy(sentiment_bing, 
         as.factor(sentiment_star), 
         as.factor(sentiment_bing)
         )

# --- Sentiment Analysis - VADER --- #
# Vader: polarity, intensity, emoticons, capitalization, punctuation and 'social media terms'
# These features include:
# A full list of Western-style emoticons ( for example - :D and :P )
# Sentiment-related acronyms ( for example - LOL and ROFL )
# Commonly used slang with sentiment value ( for example - Nah and meh )

# Five Heuristics of VADER:
#     
# Punctuation, namely the exclamation point (!), increases the magnitude of the intensity without modifying the semantic orientation. For example: “The weather is hot!!!” is more intense than “The weather is hot.”
# Capitalization, specifically using ALL-CAPS to emphasize a sentiment-relevant word in the presence of other non-capitalized words, increases the magnitude of the sentiment intensity without affecting the semantic orientation. For example: “The weather is HOT.” conveys more intensity than “The weather is hot.”
# Degree modifiers (also called intensifiers, booster words, or degree adverbs) impact sentiment intensity by either increasing or decreasing the intensity. For example: “The weather is extremely hot.” is more intense than “The weather is hot.”, whereas “The weather is slightly hot.” reduces the intensity.
# Polarity shift due to Conjunctions, The contrastive conjunction “but” signals a shift in sentiment polarity, with the sentiment of the text following the conjunction being dominant. For example: “The weather is hot, but it is bearable.” has mixed sentiment, with the latter half dictating the overall rating.
# Catching Polarity Negation, By examining the contiguous sequence of 3 items preceding a sentiment-laden lexical feature, we catch nearly 90% of cases where negation flips the polarity of the text. For example a negated sentence would be “The weather isn't really that hot.”.

# as a result VADER outperforms humans in correctly labelling sentiment 
# assigned by another human coder 
# accuracy of .96 vs .84
#

# VADER does not want a tidy df .. it wants the raw text string
# Let's do it:

vader_sents <- 
    vader_df(df$review)


# how to get sentiment from this:
# focus on the compound score which is a normalization of the sum of word sentiments 
# so the output lies between -1 and 1
# cutting into pos neg neu using the threshold suggested by original authors
vader_sents2 <- 
    vader_sents %>%
    rowid_to_column("id") %>%
    mutate(vader_class = case_when(
        compound > 0.05 ~ "positive",
        compound < -0.05 ~ "negative",
        TRUE ~ "neutral"
        )
    ) %>% 
    select(id, vader_class) %>%
    mutate(id = as.character(id))

# Was VADER Any Better?
# First merge vader results back to original data
df_vader <-
    df %>% 
    mutate(id = as.character(id)) %>%
    inner_join(vader_sents2, by = "id")

# Confusion Matrix
conf_mat(df_vader,
         sentiment_star,
         vader_class,
         dnn = c('star', 'vader'))

# Accuracy
accuracy(df_vader,
         as.factor(sentiment_star), 
         as.factor(vader_class)
         )
